#include <gtk/gtk.h>
typedef struct 
{   
    char nom[20] ;
    char prenom[20] ;
    char classe[40] ;
    char id[10] ;
    char etage[7];
}etudiant;




void affichage (char fichier[],GtkWidget *liste) ; 

etudiant recherche(char fichier[],char x[] );

void ajouter_etudiant(etudiant x) ; 

int suprimer_etudiant(char fichier[],char iden[]) ;

int modifier_etudiant(char fichier[],etudiant x) ;


int verifier(char x[]) ;




