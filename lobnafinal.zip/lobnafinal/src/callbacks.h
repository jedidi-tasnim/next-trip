#include <gtk/gtk.h>


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

gboolean
on_treeview1_select_cursor_row         (GtkTreeView     *treeview,
                                        gboolean         start_editing,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button1_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button9_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button6_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button10_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button8_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button12_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton5_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton6_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button11_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button13_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button14_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_buttonfoyerL4_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonfoyerL1_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonfoyerL9_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonfoyerL2_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonfoyerL3_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonfoyerL36_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonfoyerL5_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonfoyerL6_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonfoyerL8_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonfoyerL12_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonfoyerL10_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobuttonfoyerL4_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonfoyerL3_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonfoyerL6_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonfoyerL5_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonfoyerL11_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbuttonfoyerL1_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbuttonfoyerL2_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonfoyerL13_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonfoyerL14_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeviewfoyerL1_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

gboolean
on_treeviewfoyerL1_select_cursor_row   (GtkTreeView     *treeview,
                                        gboolean         start_editing,
                                        gpointer         user_data);
