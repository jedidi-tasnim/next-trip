#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "etudiant.h"

int x=0;
int k=0;
int y=0;
int z=0 ;
int e=0;
int q=0;
char iden[20];
etudiant cli ;
int w ;
int m;
char idd[20];

////////////////////////////////////////////////
void
on_buttonfoyerL4_clicked               (GtkButton       *object,
                                        gpointer         user_data)
{
GtkWidget *window_ajouter,*input2,*treeview1;

char fichier[]={"test.txt"};
char fichierr[]={"etudiant.txt"};
char x [10];
etudiant c ;
//partie recherche identite
window_ajouter=lookup_widget(object,"windowfoyerL1");
input2=lookup_widget(object,"entryfoyerL1");
strcpy(x,gtk_entry_get_text(GTK_ENTRY(input2)));
c=recherche(fichierr,x);
//partie fichier test
FILE *f;
f = fopen(fichier,"a+");
if ( f != NULL )
fprintf(f,"%s %s %s %s %s \n",c.nom,c.prenom,c.classe,c.id,c.etage) ;
fclose (f) ;

//partie affichage
GtkWidget *input,*input1;
input=lookup_widget(object,"windowfoyerL1");
input=create_windowfoyerL1();
gtk_widget_show(input);
input1=lookup_widget(object,"windowfoyerL1");
gtk_widget_destroy(input1);
gtk_widget_show(input);
treeview1=lookup_widget(input,"treeviewfoyerL1");
affichage(fichier,treeview1);
remove(fichier);
}


void
on_buttonfoyerL1_clicked               (GtkButton       *object,
                                        gpointer         user_data)
{
GtkWidget *input,*input1;
input=lookup_widget(object,"windowfoyerL2");
input=create_windowfoyerL2();
gtk_widget_show(input);
input1=lookup_widget(object,"windowfoyerL1");
gtk_widget_destroy(input1);
}


void
on_buttonfoyerL9_clicked               (GtkButton       *object,
                                        gpointer         user_data)
{
char fichier[]={"etudiant.txt"};
GtkWidget *input,*input1,*treeview1;
input=lookup_widget(object,"windowfoyerL1");
input=create_windowfoyerL1();
gtk_widget_show(input);
input1=lookup_widget(object,"windowfoyerL1");
gtk_widget_destroy(input1);
gtk_widget_show(input);
treeview1=lookup_widget(input,"treeviewfoyerL1");
affichage(fichier,treeview1);
}



void
on_buttonfoyerL2_clicked               (GtkButton       *object,
                                        gpointer         user_data)
{
GtkWidget *window1,*window4,*input2,*treeview1,*output,*output1,*output2,*output3,*output4,*output5,*output6;
GtkWidget *input,*input1;

char fichierr[]={"etudiant.txt"};
char x [10];
int s ;
int n=0 ;
etudiant c;


window1=lookup_widget(object,"windowfoyerL1");
input2=lookup_widget(object,"entryfoyerL10");
strcpy(x,gtk_entry_get_text(GTK_ENTRY(input2)));
s=verifier(x);
while((strcmp(x,"")!=0)&&(n==0))
{
if ( s==0)
{
output5 = lookup_widget(object,"labelfoyerL37") ;
gtk_label_set_text(GTK_LABEL(output5),"etudiant introuvable");
n=1;
}
else
{window4=lookup_widget(object,"windowfoyerL4");
window4=create_windowfoyerL4();
gtk_widget_show(window4);
gtk_widget_destroy(window1);
strcpy(iden,x);
n=1;
}
}
if(n==0)
{
output6 = lookup_widget(object,"labelfoyerL37") ;
gtk_label_set_text(GTK_LABEL(output6),"il faut donner identifiant");
}
}


void
on_buttonfoyerL3_clicked               (GtkButton       *object,
                                        gpointer         user_data)
{
GtkWidget *window_ajouter,*input2,*treeview1,*output,*output1;
GtkWidget *input,*input1,*input3;

char fichierr[]={"utlisateur.txt"};
char x [10];
int s ;
int n=0 ;

window_ajouter=lookup_widget(object,"windowfoyerL1");
input2=lookup_widget(object,"entryfoyerL11");
strcpy(x,gtk_entry_get_text(GTK_ENTRY(input2)));
s=verifier(x);
while((strcmp(x,"")!=0)&&(n==0))
{
if (s==0)
{
output = lookup_widget(object,"labelfoyerL36") ;
gtk_label_set_text(GTK_LABEL(output),"etudiant introuvable");
n=1;
}
else
{//partie affichage

input3=lookup_widget(object,"windowfoyerL6");
input3=create_windowfoyerL6();
gtk_widget_show(input3);
input1=lookup_widget(object,"windowfoyerL1");
gtk_widget_destroy(input1);
//gtk_widget_show(input2);//remarque
//treeview1=lookup_widget(input,"treeviewfoyerL1");
//affichage(fichierr,treeview1);
n=1;
strcpy(idd,x);
}
}
if(n==0)
{
output1 = lookup_widget(object,"labelfoyerL36") ;
gtk_label_set_text(GTK_LABEL(output1),"il faut donner identifiant");
}
}

////////////////////////////////////////////////////////////////////////
void
on_buttonfoyerL36_clicked              (GtkButton       *object,
                                        gpointer         user_data)
{
	//gtk_widget_show (create_Accueil ());
}


void
on_buttonfoyerL5_clicked               (GtkButton       *object,
                                        gpointer         user_data)
{
GtkWidget *input,*input1;
input=lookup_widget(object,"windowfoyerL1");
input=create_windowfoyerL1();
gtk_widget_show(input);
input1=lookup_widget(object,"windowfoyerL2");
gtk_widget_destroy(input1);
}


void
on_buttonfoyerL6_clicked               (GtkButton       *object_graphique,
                                        gpointer         user_data)//dsgg
{
GtkWidget *input1, *input2,*input3,*input4,*output,*output1,*output2;
GtkWidget *window_ajouter,*combobox1;
etudiant c;
int test ;
int n = 0 ;
char texte1[7]="1er";
char texte2[7]="2eme";

combobox1=lookup_widget(object_graphique,"comboboxfoyerL1");
window_ajouter=lookup_widget(object_graphique,"windowfoyerL2");
input1=lookup_widget(object_graphique,"entryfoyerL2");
input2=lookup_widget(object_graphique,"entryfoyerL3");
input3=lookup_widget(object_graphique,"entryfoyerL4");
input4=lookup_widget(object_graphique,"entryfoyerL5");

/*if(strcmp(texte1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)))==0)
strcpy(c.etage,texte1);
if(strcmp(texte2,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)))==0)
strcpy(c.etage,texte2);*/

strcpy(c.etage,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(c.prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(c.classe,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(c.id,gtk_entry_get_text(GTK_ENTRY(input4)));

test = verifier(c.id);
while((strcmp(c.nom,"")!=0)&&(strcmp(c.prenom,"")!=0)&&(strcmp(c.classe,"")!=0)&&(strcmp(c.id,"")!=0)&&(n==0))
{
if(test==1)
{
output = lookup_widget(object_graphique,"labelfoyerL7") ;
gtk_label_set_text(GTK_LABEL(output),"identite deja existe");
n=1;
}
else
{
cli=c ;
GtkWidget *input0,*input00;
input0=lookup_widget(object_graphique,"windowfoyerL5");
input0=create_windowfoyerL5();
gtk_widget_show(input0);
input00=lookup_widget(object_graphique,"windowfoyerL2");
gtk_widget_destroy(input00);
n=1;

}
}
if(n==0)
{
output2=lookup_widget(object_graphique,"labelfoyerL7");
gtk_label_set_text(GTK_LABEL(output2),"remplir tout les informations!");
}
}


void
on_buttonfoyerL8_clicked               (GtkButton       *object,
                                        gpointer         user_data)
{
GtkWidget *input,*input1;
input=lookup_widget(object,"windowfoyerL1");
input=create_windowfoyerL1();
gtk_widget_show(input);
input1=lookup_widget(object,"windowfoyerL3");
gtk_widget_destroy(input1);
}


void
on_buttonfoyerL12_clicked              (GtkButton       *object,
                                        gpointer         user_data)
{
GtkWidget *input1,*input2,*input3,*input4,*output1,*output2,*output3;
GtkWidget *window3;

etudiant x;
int m ;
int test ;
int n=0;
char fichierr[]={"etudiant.txt"};
char text1[6]="1er";
char text2[6]="2eme";
window3=lookup_widget(object,"windowfoyerL3");
if(y==1)
strcpy(x.etage,text1);
if(y==2)
strcpy(x.etage,text2);


input1=lookup_widget(object,"entryfoyerL6");
input2=lookup_widget(object,"entryfoyerL7");
input3=lookup_widget(object,"entryfoyerL9");
input4=lookup_widget(object,"entryfoyerL8");


strcpy(x.nom,gtk_entry_get_text(GTK_ENTRY(input1)));//nom modifiée
strcpy(x.prenom,gtk_entry_get_text(GTK_ENTRY(input2)));//prenom modifiée
strcpy(x.id,gtk_entry_get_text(GTK_ENTRY(input3)));//id 
strcpy(x.classe,gtk_entry_get_text(GTK_ENTRY(input4)));//classe modifiéé



//partie validation de modification

test = verifier(x.id);

while((strcmp(x.nom,"")!=0)&&(strcmp(x.prenom,"")!=0)&&(strcmp(x.classe,"")!=0)&&(strcmp(x.id,"")!=0)&&(n==0))
{
if (test==1)
{

m =modifier_etudiant(fichierr,x);
output1 = lookup_widget(object,"labelfoyerL35") ;
gtk_label_set_text(GTK_LABEL(output1),"etudiant modifié avec succes");
n=1;
}
else
{
output2 = lookup_widget(object,"labelfoyerL35") ;
gtk_label_set_text(GTK_LABEL(output2),"identifiant n'existe pas");
n=1;
}
}
if(n==0)
{
output3 = lookup_widget(object,"labelfoyerL35") ;
gtk_label_set_text(GTK_LABEL(output3),"il faut remplir tout les information");
}
}


void
on_buttonfoyerL10_clicked              (GtkButton       *object,
                                        gpointer         user_data)
{
GtkWidget *window3;
GtkWidget *output,*output1,*output2,*output3,*output4;
etudiant c ;
char fichier[]={"etudiant.txt"};
c=recherche(fichier,iden);
output = lookup_widget(object,"labelfoyerL29") ;
gtk_label_set_text(GTK_LABEL(output),c.nom);
output1 = lookup_widget(object,"labelfoyerL30") ;
gtk_label_set_text(GTK_LABEL(output1),c.prenom);
output2 = lookup_widget(object,"labelfoyerL33") ;
gtk_label_set_text(GTK_LABEL(output2),c.id);
output3 = lookup_widget(object,"labelfoyerL32") ;
gtk_label_set_text(GTK_LABEL(output3),c.classe);
output4 = lookup_widget(object,"labelfoyerL31") ;
gtk_label_set_text(GTK_LABEL(output4),c.etage);
}


void
on_radiobuttonfoyerL4_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{y=2;}
}


void
on_radiobuttonfoyerL3_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{y=1;}
}


void
on_radiobuttonfoyerL6_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{z=2;}
}


void
on_radiobuttonfoyerL5_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{z=1;}
}


void
on_buttonfoyerL11_clicked              (GtkButton       *object,
                                        gpointer         user_data)
{
GtkWidget *input,*input1,*input3,*input4,*input5;
if(z==1)
{
input=lookup_widget(object,"windowfoyerL3");
input=create_windowfoyerL3();
gtk_widget_show(input);
input1=lookup_widget(object,"windowfoyerL1");
gtk_widget_destroy(input1);
input3=lookup_widget(object,"windowfoyerL4");
gtk_widget_destroy(input3);
}
if(z==2)
{
input4=lookup_widget(object,"windowfoyerL1");
input4=create_windowfoyerL1();
gtk_widget_show(input4);
input5=lookup_widget(object,"windowfoyerL4");
gtk_widget_destroy(input5);

}
}


void
on_checkbuttonfoyerL1_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{w=1;}
else
{w=0;}
}


void
on_checkbuttonfoyerL2_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{m=1;}
else
{m=0;}
}


void
on_buttonfoyerL13_clicked              (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
int n = 0 ;
while((m!=w)&&(n==0))
{
if(w==1)
{
ajouter_etudiant(cli);
GtkWidget *input,*input1,*input2;
input=lookup_widget(objet_graphique,"windowfoyerL1");
input=create_windowfoyerL1();
gtk_widget_show(input);
input1=lookup_widget(objet_graphique,"windowfoyerL2");
gtk_widget_destroy(input1);
input2=lookup_widget(objet_graphique,"windowfoyerL5");
gtk_widget_destroy(input2);
n=1;
}
if(m==1)
{
GtkWidget *input3,*input4;
input4=lookup_widget(objet_graphique,"windowfoyerL2");
input4=create_windowfoyerL2();
gtk_widget_show(input4);
input3=lookup_widget(objet_graphique,"windowfoyerL5");
gtk_widget_destroy(input3);
n=1;
}
}
if(n==0)
{
GtkWidget *output2,*input5;
input5=lookup_widget(objet_graphique,"windowfoyerL5");
output2 = lookup_widget(objet_graphique,"labelfoyerL44") ;
gtk_label_set_text(GTK_LABEL(output2),"choisir oui ou non");
}
}


void
on_buttonfoyerL14_clicked              (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *spinbuttonfoyerL1;
GtkWidget *input,*input1,*input2,*input3,*input4,*treeview1;
char fichierr[]={"etudiant.txt"};
int a,s ;
spinbuttonfoyerL1=lookup_widget(objet_graphique,"spinbuttonfoyerL1");
a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbuttonfoyerL1));
if(a==1)
{
s=suprimer_etudiant(fichierr,idd);
input=lookup_widget(objet_graphique,"windowfoyerL1");
input=create_windowfoyerL1();
gtk_widget_show(input);
input1=lookup_widget(objet_graphique,"windowfoyerL6");
gtk_widget_destroy(input1);

treeview1=lookup_widget(input,"treeviewfoyerL1");
affichage(fichierr,treeview1);
}
if(a==0)
{
input3=lookup_widget(objet_graphique,"windowfoyerL6");
gtk_widget_destroy(input3);
input2=lookup_widget(objet_graphique,"windowfoyerL1");
input2=create_windowfoyerL1();
gtk_widget_show(input2);
treeview1=lookup_widget(input4,"treeviewfoyerL1");
affichage(fichierr,treeview1);
}
}


void
on_treeviewfoyerL1_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
{
GtkTreeIter iter;
gchar* nom ;
gchar* prenom;
gchar* classe;
gchar* id;
gchar* etage;
etudiant c;

char fichier[]={"etudiant.txt"};

GtkTreeModel *model = gtk_tree_view_get_model(treeview);
if(gtk_tree_model_get_iter(model,&iter,path))
{
gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&nom,1,&prenom,2,&classe,3,&id,4,&etage,-1);

strcpy(c.id,id);
strcpy(c.nom,nom);
strcpy(c.prenom,prenom);
strcpy(c.classe,classe);
strcpy(c.etage,etage);

affichage(fichier,treeview);
}
}


gboolean
on_treeviewfoyerL1_select_cursor_row   (GtkTreeView     *treeview,
                                        gboolean         start_editing,
                                        gpointer         user_data)
{

  return FALSE;
}
}

